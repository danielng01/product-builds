Iris micro protects your eyes in under 1MB

For day time settings double click
day_mode.sh

For night time settings double click
night_mode.sh

To remove the changes caused by Iris micro double click
reset.sh

You can also call Iris micro with custom values for example
iris-micro.exe 2000 50
Will set temperature on 2000K and brightness on 50%

For problems and feedback
daniel@iristech.co

Enjoy :)