#!/usr/bin/env bash

`dirname $0`/iris-micro 3400 80
$SHELL
