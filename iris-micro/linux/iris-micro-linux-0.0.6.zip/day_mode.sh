#!/bin/bash

`dirname $0`/iris-micro 5000 100
$SHELL
