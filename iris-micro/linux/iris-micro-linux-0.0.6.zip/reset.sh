#!/usr/bin/env bash

`dirname $0`/iris-micro 6500 100
$SHELL
