#!/usr/bin/env bash

`dirname $0`/iris-micro.sh 6500 100
$SHELL
