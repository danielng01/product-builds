#!/usr/bin/env bash

`dirname $0`/iris-micro.sh 3400 80
$SHELL
