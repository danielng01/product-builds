Iris micro protects your eyes in under 1MB

For day time settings double click
day_mode.bat

For night time settings double click
night_mode.bat

To remove the changes caused by Iris micro double click
reset.bat

Windows has some limitations that we fix with the file
expand_range.reg
1. Double click it
2. Press Yes
3. And Restart your PC
for better eye protection

Enjoy :)