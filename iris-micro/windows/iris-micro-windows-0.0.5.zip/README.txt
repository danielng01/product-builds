Iris micro protects your eyes in under 1MB

For day time settings double click
day_mode.bat

For night time settings double click
night_mode.bat

To remove the changes caused by Iris micro double click
reset.bat

On Windows values bellow 3900K and 80% will not work by default. To enable lower values there is one file in the folder called

expand_range.reg
1. Double click it
2. Press Yes
3. And Restart your PC

Now everything should work and you can set low values.

You can also call Iris micro with custom values for example
iris-micro.exe 2000 50
Will set temperature on 2000K and brightness on 50%

For problems and feedback
daniel@iristech.co

Enjoy :)