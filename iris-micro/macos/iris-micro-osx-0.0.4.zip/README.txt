Iris micro protects your eyes in under 1MB

For day time settings double click 
day_mode.command

For night time settings double click
night_mode.command

If you hate that Terminal should be open double click
run_without_terminal.command
and the process will run in background

You can also call Iris micro with custom values for example
./iris-micro 2000 50
Will set temperature on 2000K and brightness on 50%

I also code signed the exec file, but GateKeeper still doesn’t allow exec files so if you get “unidentified developer” or some other error
System Preferences -> Security and Privacy
and allow Apps from unidentified developers.
As long as you download Iris micro from the http://iristech.co website you are safe.

If this whole command line thing is hard to you use Iris mini. It’s more easy to use.

For problems and feedback
daniel@iristech.co

Enjoy :)