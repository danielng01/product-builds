Iris micro protects your eyes in under 1MB

For day time settings run in Terminal
./day_mode.sh

For night time settings run in Terminal
./night_mode.sh

You can also call Iris micro with custom values for example
./iris-micro 2000 50
Will set temperature on 2000K and brightness on 50%

For problems and feedback
daniel@iristech.co

Enjoy :)