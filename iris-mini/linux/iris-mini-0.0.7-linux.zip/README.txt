For 64-bit Linux:
sudo dpkg --add-architecture i386
sudo apt-get update
sudo apt-get dist-upgrade

Then start Iris mini with:
sh iris-mini.sh

For 32-bit Linux:
Double click iris-mini

(If it doesn't start right click and in Permissions tab check Execute check box)

If you don't see the tray icon, but ? image run it with sudo

If you have problems starting Iris please write to me at: daniel@iristech.co