To start Iris run:
bash Iris.sh

If you don't see the tray icon, but ? image run it with sudo

If you have problems starting Iris please write to us at: contact@iristech.co