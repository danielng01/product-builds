# Night Shift on Unsupported Macs


Version 2.0.1 - GUI Installer
Version 2.0 - Bash Script

Updated July 31, 2019 

Night Shift Enable Script for Unsupported Macs
Script made by [Isiah Johnson (TMRJIJ)](https://IsiahJohnson.com "Isiah Johnson") / [OS X Hackers](http://osxhackers.net/NightShift "OS X Hackers") & [Dosdude1](http://dosdude1.com "Dosdude1")

![alt tag](http://osxhackers.net/img/sunsetLogo.jpg)

This script will replace the CoreBrightness.framework with one already patched with the matching hex value in CoreBrightness.framework for most older/unsupported hardware.

All credits for this work goes to Piker Alpha. Thanks!
Special thanks to [pookjw](https://github.com/pookjw/), PeterHolbrook, [dosdude1](https://github.com/dosdude1/), and [aonez](https://github.com/aonez/) for their continued critiques and support from their own source work.

As requested, this script is intended as non-commerical, with no Donation requests, Open Source, and must give thanks to Pike!
Blog URL: [Click Here](https://pikeralpha.wordpress.com/2017/01/30/4398/)

# Announcements

- I deeply apologize for the lack of updates. College life was pretty busy. 
- I will work in the Backup and Uninstaller Issues facing the v2.0 patch.
- It looks like I may need to make a script for re-patching as well.

![alt tag](http://dl.osxhackers.net/.images/NightShift.png)

# History

macOS Sierra 10.12.4 brings iOS's Night Shift mode to the Mac for the first time. Night Shift, first introduced on iOS devices in iOS 9.3, is designed to gradually shift the display of a device from blue to a subtle yellow, cutting down on exposure to blue light. Blue light is believed to interrupt the circadian rhythm, disrupting sleep patterns. 

Night Shift is activated through the Displays section of System Preferences, where a setting to have it come on at sunset and turn off at sunrise is available. It can also be set to turn on and off at custom times. Night Shift can also be toggled on manually using the Notification Center or Siri. 

Night Shift was introduced in macOS Sierra 10.12.4 (16E144f) and is controlled by the CoreBrightness.framework. The official minimum requirements for this feature are: 

- MacBookPro9,x
- iMacPro1,x
- iMac13,x
- Macmini6,x
- MacBookAir5,x
- MacPro6,x
- MacBook8,x

Of course, this patch is intended to bypass this check completely.

# OS Version Requirements

- macOS 10.12 Sierra Supported
- macOS 10.13 High Sierra Supported
- macOS 10.14 Mojave Supported

-macOS 10.15 Catalina has not been Tested yet. Stay Tuned for updates.


# Patching Instructions

Note: System Integrity Protection must be disabled beforehand in order to patch the framework. You can re-enable it after you're done. Software Updates may revert this patch so always check this repository for updates. [HOW TO DISABLE SIP?](http://apple.stackexchange.com/questions/208478/how-do-i-disable-system-integrity-protection-sip-aka-rootless-on-os-x-10-11 )

Always BACKUP before attempting this patch!

Installer Patching:

1. Open the Installer in the Root of the Repository
2. Follow the steps and agree to the terms 
3. Install
4. Upon Completion, Restart your Mac
5. You will see that the Night Shift tab is now available in System Preferences > Display as well as the toggle at the top of your Notification Center.

![alt tag](http://dl.osxhackers.net/.images/NS_Installer.png)

Script Patching:

1. Open the Terminal app in your Applications Folder
2. Drag the 'Enable NightShift.sh' into the Terminal Window
3. Following the instructions
4. After Patching. Restart your Mac.
5. You will see that the Night Shift tab is now available in System Preferences > Display as well as the toggle at the top of your Notification Center.

![alt tag](http://dl.osxhackers.net/.images/NS_Script.png)

# Uninstall

1. Open the Terminal app in your Applications Folder
2. Drag the 'Uninstaller.sh' into the Terminal Window
3. Following the instructions
4. After Reverting. Restart your Mac.
5. You will see that the Night Shift tab is no longer available.
    
Note: v2.0 is also compatible with the other scripts for repatching and uninstallation.

# Known Bugs

- Certain Third-party monitors are NOT Compatible with this Patch.
- Certain Models and configurations can be left with a Disabled Notification Center and the inability to open the DIsplay and/or Energy Saver Preferences Pane in System Preferences.



# Support

As such, if something goes wrong (like the Display tab in System Preference crashing) or if this framework copy doesn't work. Please feel free to email me at support@osxhackers.net, let me know in the Issues Tab, or attempt it manually via [Pike's original blog post.](https://pikeralpha.wordpress.com/2017/01/30/4398/)

Also join the rest of the Unsupported Mac Community on [our Discord Server](https://discord.gg/XbbWAsE)

Have Fun!

# Other Notable Night Shift Patches
1. [NightPatch by pookjw](https://github.com/pookjw/NightPatch)
2. [NightShiftPatcher by aonez](https://github.com/aonez/NightShiftPatcher)



