Qt-Linguist
===========
Because tracking this sucker down is too hard, and so is building all of Qt.

Current version = 5.4.2

Windows releases only.
