See http://neosmart.net/blog/2007/windows-vistas-gamma-table-bug/ for more info 
about DisplayProfile and how to use it to fix your gamma settings.



File hosted by NeoSmart Technologies.

Donate today and help cover our hosting fees:
http://neosmart.net/donations.php
