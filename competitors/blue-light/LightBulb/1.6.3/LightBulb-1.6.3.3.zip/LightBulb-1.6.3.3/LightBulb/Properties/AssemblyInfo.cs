﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;

[assembly: AssemblyTitle("LightBulb")]
[assembly: AssemblyDescription("Gamma control aplication")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Tyrrrz")]
[assembly: AssemblyProduct("LightBulb")]
[assembly: AssemblyCopyright("Copyright © Alexey Golub 2017")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: AssemblyVersion("1.6.3.3")]
[assembly: AssemblyFileVersion("1.6.3.3")]