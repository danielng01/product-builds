0. Make sure .NET Framework 4.5.2 is installed
1. Copy the contents to a directory with write permissions
2. If you haven't before, update computer's gamma range:
	2a. Run Manual_Gamma_Registry_Fix.reg as administrator
	2b. Restart computer
3. Use LightBulb_Portable.bat to launch the program (don't launch the exe directly)