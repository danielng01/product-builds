﻿namespace LightBulb.Views
{
    public partial class GeoSettingsView
    {
        public GeoSettingsView()
        {
            InitializeComponent();
        }
    }
}
