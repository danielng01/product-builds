﻿namespace LightBulb.Views
{
    public partial class AdvancedSettingsPage
    {
        public AdvancedSettingsPage()
        {
            InitializeComponent();
        }
    }
}
