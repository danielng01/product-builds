﻿namespace LightBulb.Models
{
    public enum CycleState
    {
        Disabled, Transition, Day, Night
    }
}
