﻿namespace LightBulb.Views
{
    public partial class AdvancedSettingsView
    {
        public AdvancedSettingsView()
        {
            InitializeComponent();
        }
    }
}
