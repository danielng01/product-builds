﻿using System;

namespace LightBulb.Models
{
    public class SolarInfo
    {
        public DateTime Sunrise { get; set; }

        public DateTime Sunset { get; set; }
    }
}
