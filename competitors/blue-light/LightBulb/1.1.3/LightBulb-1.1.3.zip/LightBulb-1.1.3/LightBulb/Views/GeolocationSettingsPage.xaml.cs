﻿namespace LightBulb.Views
{
    public partial class GeolocationSettingsPage
    {
        public GeolocationSettingsPage()
        {
            InitializeComponent();
        }
    }
}
