
Redshift
========

Redshift adjusts the color temperature of your screen according to
your surroundings. This may help your eyes hurt less if you are
working in front of the screen at night.

Run `redshift -h' for help on command line options. You can run the program
as `redshift-gtk' instead of 'redshift' for a graphical status icon.

Website:	http://jonls.dk/redshift/
Project page:	http://launchpad.net/redshift


Building from source
--------------------

See the file HACKING for more details on building from source.
