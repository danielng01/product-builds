
  Night Mode for Windows
  version 0.0.2.0
  (c) 2013 - 2014 Copyrights by FloatOverflow

  http://floatoverflow.blogspot.com/
  

1. Unpack zip file into some folder

2. Start nightmode.exe

3. Go to system tray and click Night Mode for Windows icon

4. Select "Options" and set if you want to start this program with Windows

