
  Night Mode for Windows
  version 0.0.3.0
  (c) 2013 - 2015 Copyright by FloatOverflow

  http://floatoverflow.blogspot.com/
  


1. Unpack zip file into folder you want or use installer.

2. Start nightmode.exe.

3. Go to system tray and right-click "Night Mode for Windows" icon.

4. Select appropriate percent to dim your screen.

5. Select "Help" to see manual.

6. If you want to start this program with Windows, select "Options"
and set check-box "Start this program automatically with Windows"
and click "Apply & close". This option works only when you start
the program with Administrator's rights.

